import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import axios from './axiosConfig'; // Import your Axios instance
import './HomePage.css';
import videoSource from './media/market_-_122881 (Original) (1).mp4';
import bitcoin from './media/bitcoin.png';
import exit from './media/logout.png';
const HomePage = ({ setIsLoggedIn }) => {
  const navigate = useNavigate();

  // Function to handle signout
  const handleSignout = async () => {
    try {
      // Send a POST request to the logout endpoint on the server
      await axios.post('http://localhost:3000/api/auth/logout');

      // Clear the token from localStorage or your preferred storage
      localStorage.removeItem('token');
      console.log(localStorage);
      setIsLoggedIn(false);
      navigate('/login');
    } catch (error) {
      console.error('Error during signout:', error);
      // Handle signout failure, e.g., show an error message
    }
  };

  return (
    
    <div className="home-container">
      <video className="video-background" autoPlay loop muted preload="auto">
        <source src={videoSource} type="video/mp4" />
        Your browser does not support the video tag.
      </video>
      <div className="signout-options">
        <Link to="/signup"></Link>
        <button className="signout-button" onClick={handleSignout}>
        <img src={exit} alt="img"/> Sign Out</button>
      </div>
      <h1 className="home-title glowing-text"><img src={bitcoin} alt="img"/>PAYCRYPTO</h1>
      <p className="home-description">Choose an option:</p>
      <div className="home-options">
        <Link to="/Crypto-Price-Page">
          <button className="home-button">Crypto Price Page</button>
        </Link>
        <Link to="/Crypto-Wallet-Page">
          <button className="home-button">Crypto Wallet Page</button>
        </Link>
        <Link to="/Transactions-Page">
          <button className="home-button">Transactions Page</button></Link>
          
      </div>
    </div>
  );
};

export default HomePage;
