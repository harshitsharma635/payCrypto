
import React, { useState, useEffect } from 'react';
import './LoginSignupPage.css';
import { Link, useNavigate} from 'react-router-dom';
import axios from './axiosConfig';
import videoSource from './media/market_-_122881 (Original) (1).mp4';
import bitcoin from './media/bitcoin.png';
import fail from './media/close.png';
import register from './media/pen.png';
import success from './media/checked.png';
import login1 from './media/login.png';
import home1 from './media/house.png';


const LoginSignupPage = ({ setIsLoggedIn, isLoggedIn, setSignupData, signupData, token }) => {
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    dob: '',
    email: '',
    institution: '',
    username: '',
    password: '',
  });
  const [isSignedUp, setIsSignedUp] = useState(false);
  const [isLoginMode, setIsLoginMode] = useState(false);
  const [isLoginFailed, setIsLoginFailed] = useState(false);
  const navigate = useNavigate();
  
  
  useEffect(() => {
    // Check if the user is logged in when the component mounts
    if (token) {
      setIsLoggedIn(true);
    }
  }, [token, setIsLoggedIn]);

  const [error, setError] = useState('');
  
  // Function to handle user registration
  const handleSignupClick = async (e) => {
    e.preventDefault();

    try {
      // Make a POST request to the registration endpoint
      const response = await axios.post('http://localhost:3000/api/auth/register', formData);

      console.log('User registered successfully:', response.data);
      setIsSignedUp(true);
      setIsLoginMode(true);
      setError(null);
      
    } catch (error) {
      console.error('Registration failed:', error.response.data);
      setError(error.response.data.message);
      // Handle registration failure, e.g., show an error message
    }
  };
  
  // Function to handle user login
  const handleLogin = async (e) => {
    e.preventDefault();

    try {
      // Make a POST request to the login endpoint
      const response = await axios.post('http://localhost:3000/api/auth/login', {
        username: formData.username,
        password: formData.password,
      });
      const { user, token } = response.data; // Extract the user and token from the response
      console.log('Received Token:', token);
      console.log('User logged in successfully:', user);
      localStorage.setItem('token', token);
      setError(null);
      setIsLoggedIn(true);
      navigate('/home'); // Redirect to the home page on successful login
    } catch (error) {
      console.error('Login failed:', error.response.data);
      setIsLoginFailed(true);
      setError(error.response.data.message);
    }
  };

  // // Function to handle user logout
  // const handleLogout = () => {
  //   // Clear the token from local storage
  //   localStorage.removeItem('token');
  //   setIsLoggedIn(false);
  // };

  return (
    
    <div className="login-signup-container">
      <video className="video-background" autoPlay loop muted preload="auto">
        <source src={videoSource} type="video/mp4" />
        Your browser does not support the video tag.
      </video>
      {isLoggedIn ? (
        <div className="login-status">
         <p>You are already logged in. Click <Link to="/home" ><img src={home1} alt="img"/></Link> to return to the Home page.</p>
         
        </div>
      ) : (
        <>
          
          <div className="banner">
          <h1 className="title glowing-text"><img src={bitcoin} alt="img"/>PAYCRYPTO</h1></div>
          <form className="login-signup-form" style={{ marginTop: '105px' }} onSubmit={isLoginMode ? handleLogin : handleSignupClick}>
            {!isLoginMode && (
              <>
                <input
                  type="text"
                  className="form-input"
                  placeholder="First Name"
                  name="firstName"
                  value={formData.firstName}
                  onChange={(e) => setFormData({ ...formData, firstName: e.target.value })}
                />
                <input
                  type="text"
                  className="form-input"
                  placeholder="Last Name"
                  name="lastName"
                  value={formData.lastName}
                  onChange={(e) => setFormData({ ...formData, lastName: e.target.value })}
                />
                <input
                  type="text"
                  className="form-input"
                  placeholder="Date of Birth (dd/mm/yyyy)"
                  name="dob"
                  value={formData.dob}
                  onChange={(e) => setFormData({ ...formData, dob: e.target.value })}
                />
                <input
                  type="email"
                  className="form-input"
                  placeholder="Email"
                  name="email"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                />
               
              </>
            )}
            <input
              type="text"
              className="form-input"
              placeholder="Username"
              name="username"
              value={formData.username}
              onChange={(e) => setFormData({ ...formData, username: e.target.value })}
            />
            <input
              type="password"
              className="form-input"
              placeholder="Password"
              name="password"
              value={formData.password}
              onChange={(e) => setFormData({ ...formData, password: e.target.value })}
            />
            {isLoginMode ? ( //img stuff can go after this div
              <div>                    
                <button 
                  type="submit"
                  className={`form-button login-signup-button` } 
                > <img src={login1} alt="img"/>
                  {isLoginMode ? 'Login' : 'Register'}
                </button>
                <Link to="/forgot-password">Forgot Password?</Link>
                {!isSignedUp && (
                  <p className="notreg">
                    Not registered?{' '}
                    <Link to="/signup" onClick={() => {setIsLoginMode(false);setIsLoginFailed(false); setIsSignedUp(false); setError('');}}>
                      Signup
                    </Link>
                  </p>
                )}
              </div>
            ) : (
              <button
                type="submit"
                className={`form-button login-signup-button`}
              >
                <img src={register} alt="img"/>Register
              </button>
            )}
          </form>
          
          {error && <p className="error-message"><img src={fail} alt="img"/>{error}</p>} {/* Display error message if it exists */}
          {isSignedUp && (
             <div className="message-box0">
             <p><img src={success} alt="img"/> User registered successfully!</p>
           </div>
          )} 
            <>
              {/* <p>OR</p>
              <div className="social-login-icons">
                <img src="/google-logo.png" alt="Google" />
                <img src="/github-logo.png" alt="GitHub" />
                <img src="/facebook-logo.png" alt="Facebook" />
              </div> */}
              {!isLoginMode && (
                <div className="message-box0">
                <p>
                  Already have an account?{' '}
                  <Link to="/login" onClick={() => {setIsLoginMode(true); setError('');}}>
                   Login
                  </Link>
                </p>
                </div>
              )}
            </>
          
          {isLoginFailed && (
            <div className="message-box0">
            <p>
              Login failed.{' '}
              <Link
                to="/login"
                onClick={() => {
                  setIsLoginMode(true);
                  setIsLoginFailed(false);
                  setError('');
                }}
              >
                Retry
              </Link>{' '}
              or{' '}
              <Link
                to="/signup"
                onClick={() => {
                  setIsLoginMode(false);
                  setIsLoginFailed(false);
                  setIsSignedUp(false);
                  setError('');
                }}
              >
                Return to Signup
              </Link>
            </p>
            </div>
          )}
        </>
      )}
    </div>
  );
};

export default LoginSignupPage;