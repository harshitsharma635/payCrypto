import React from 'react';
import { useNavigate } from 'react-router-dom';
import './NotFoundPage.css'; // Import the CSS style
import notfound from './media/no-results.png';
const NotFoundPage = () => {
  const navigate = useNavigate();

  const handleGoBack = () => {
    const token = localStorage.getItem('token'); // Check if a token exists in local storage

    if (token) {
      // If a token exists, consider the user as logged in and go to the home page
      navigate('/home');
    } else {
      // If no token exists, consider the user as not logged in and go to the login page
      navigate('/login');
    }
  };

  return (
    <div className="not-found-container">
      <div className="not-found-box">
      <h1 className="not-found-title"><img src={notfound} alt="img"/>404 Not Found</h1>
      <p className="not-found-description">The page you're looking for does not exist.</p>
      <button className="not-found-button" onClick={handleGoBack}>
        Go Back
      </button>
      </div>
    </div>
  );
};

export default NotFoundPage;
