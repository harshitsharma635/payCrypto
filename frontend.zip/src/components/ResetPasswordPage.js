import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom'; // Import useLocation from react-router-dom
import axios from './axiosConfig';
import './ResetPasswordPage.css';
import videoSource from './media/market_-_122881 (Original) (1).mp4';
import reset from './media/password.png';
import success from './media/checked.png';
import fail from './media/close.png';
const ResetPasswordPage = () => {
  const location = useLocation(); // Use useLocation to access the current location
  const token = new URLSearchParams(location.search).get('token'); // Extract the 'token' from the query parameters

  const [formData, setFormData] = useState({ newPassword: '', confirmPassword: '' });
  const [passwordsMatch, setPasswordsMatch] = useState(true);
  const [successMessage, setSuccessMessage] = useState(false);

  const handlePasswordReset = async (e) => {
    e.preventDefault();
    console.log('New Password:', formData.newPassword);
    console.log('Confirm Password:', formData.confirmPassword);
    if (formData.newPassword === formData.confirmPassword) {
      try {
        // Send a POST request to your backend endpoint for password reset, including the 'token'
        const response = await axios.post(`http://localhost:3000/api/password-reset/reset?token=${token}`, {
          newPassword: formData.newPassword,
          confirmPassword: formData.confirmPassword,
        });

        if (response.status === 200) {
          // Password reset successful
          setPasswordsMatch(true);
          setSuccessMessage(true);
        }
      } catch (error) {
        // Handle errors, e.g., show an error message
        setPasswordsMatch(false);
      }
    } else {
      setPasswordsMatch(false);
    }
  };

  return (
    <div className="reset-password-container">
      <video className="video-background" autoPlay loop muted preload="auto">
        <source src={videoSource} type="video/mp4" />
        Your browser does not support the video tag.
      </video>
      <div className="message-box1">
      <h2><img src={reset} alt="img"/>Reset Password</h2>
      <form className="reset-password-form" onSubmit={handlePasswordReset}>
        <input
          type="password"
          className="form-input"
          value={formData.newPassword}
          onChange={(e) => setFormData({ ...formData, newPassword: e.target.value })}
          placeholder="Enter new password"
        />
        <input
          type="password"
          className="form-input"
          value={formData.confirmPassword}
          onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
          placeholder="Confirm new password"
        />
        <button type="submit" className="form-button">
          Reset Password
        </button>
      </form>
      </div>
      {passwordsMatch && successMessage && (
        <div className="message-box1">
        <p className="success-message">
        <img src={success} alt="img"/>Password reset successfully. <Link to="/login">Login</Link>
        </p>
        </div>
      )}
      {!passwordsMatch && (
        <p className="error-message1"><img src={fail} alt="img"></img>Passwords don't match. Please try again.</p>
      )}
    </div>
  );
};

export default ResetPasswordPage;
