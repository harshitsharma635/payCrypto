// CryptoWalletPage.js
import videoSource from './media/market_-_122881 (Original) (1).mp4';
import React, { useState } from 'react';
import './CryptoWalletPage.css'; // Import the stylesheet
import { Link, useNavigate } from 'react-router-dom';

const CryptoWalletPage = () => {
  const [cryptoBalance, setCryptoBalance] = useState(0);

  const handleDeposit = amount => {
    setCryptoBalance(prevBalance => prevBalance + parseFloat(amount));
  };

  const handleWithdraw = amount => {
    setCryptoBalance(prevBalance => prevBalance - parseFloat(amount));
  };

  return (
    <div className="crypto-wallet-container">
      <h1>Your Wallet Details:</h1>
      <video className="video-background" autoPlay loop muted preload="auto">
        <source src={videoSource} type="video/mp4" />
        Your browser does not support the video tag.
      </video>
      <div className="balance-display">Balance: {cryptoBalance.toFixed(2)} BTC</div>
      <form className="deposit-withdraw-form">
        <input
          type="number"
          className="form-input"
          placeholder="Deposit Amount (BTC)"
          onChange={e => handleDeposit(e.target.value)}
        />
        <input
          type="number"
          className="form-input"
          placeholder="Withdraw Amount (BTC)"
          onChange={e => handleWithdraw(e.target.value)}
        />

        <Link to="/home">
          <button className="home-button">Return to Home</button>
        </Link>

        <button type="submit" className="form-button">
          Submit
        </button>
      </form>
    </div>
  );
};

export default CryptoWalletPage;