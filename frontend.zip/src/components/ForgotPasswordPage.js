import './ForgotPasswordPage.css';
import React, { useState } from 'react';
import axios from './axiosConfig'; // Import axios
import videoSource from './media/market_-_122881 (Original) (1).mp4';
import mail from './media/email.png';
import send from './media/send.png';
import login1 from './media/login.png';
import fail from './media/close.png';
const ForgotPasswordPage = () => {
  const [formData, setFormData] = useState({ email: '' });
  const [isEmailValid, setIsEmailValid] = useState(true);
  const [successMessage, setSuccessMessage] = useState(false);

  const handleEmailSubmit = async (e) => {
    e.preventDefault();

    try {
      // Send a POST request to your backend endpoint for email validation
      const response = await axios.post('http://localhost:3000/api/password-reset/forgot', {
        email: formData.email,
      });

      if (response.status === 200) {
        // Email exists, update the state to show success message
        setIsEmailValid(true);
        setSuccessMessage(true);
      }
    } catch (error) {
      // Handle errors, e.g., show an error message
      setIsEmailValid(false);
    }
  };

  return (
    <div className="forgot-password-container">
      <video className="video-background" autoPlay loop muted preload="auto">
        <source src={videoSource} type="video/mp4" />
        Your browser does not support the video tag.
      </video>
      {!successMessage ? (
        <div className="message-box2">
          <h2><img src={mail} alt="img"/> Enter your Email address</h2>
          <form className="forgot-password-form" onSubmit={handleEmailSubmit}>
            <input
              type="email"
              className="form-input"
              value={formData.email}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
            />
            <button type="submit" className="form-button2">
            <img src={login1} alt="img"/> Submit
            </button>
          </form>
          {!isEmailValid && (
            
            <p className="error-message2"><img src={fail} alt="img"/>Email not found. Please try again.</p>
          )}
        </div>
      ) : (
        <div className="message-box2">
          <p className="success-message"><img src={send} alt="img"/>Password reset email sent. Check your email.</p>
        </div>
      )}
    </div>
  );
};

export default ForgotPasswordPage;
