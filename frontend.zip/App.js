import React, { useState } from 'react';
import { BrowserRouter as Router, Route, Routes, Navigate } from 'react-router-dom';
import HomePage from './components/HomePage';
import LoginSignupPage from './components/LoginSignupPage';
import ForgotPasswordPage from './components/ForgotPasswordPage';
import ResetPasswordPage from './components/ResetPasswordPage'; 
import NotFoundPage from './components/NotFoundPage'; 
import './App.css';
import MorphologicalClassifier from './components/MorphologicalClassifier';
import ImageGenerator from './components/GAN';
function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [signupData, setSignupData] = useState({});

  // Custom route wrapper function to handle private routes
  const PrivateRoute = ({ element, ...props }) => {
    return isLoggedIn ? element : <Navigate to="/not-found" />;
  };

  return (
    <Router>
      <div>
        <Routes>
          <Route path="/login" element={<LoginSignupPage setIsLoggedIn={setIsLoggedIn} setSignupData={setSignupData} signupData={signupData} isLoggedIn={isLoggedIn} />} />
          <Route path="/signup" element={<LoginSignupPage setIsLoggedIn={setIsLoggedIn} setSignupData={setSignupData} signupData={signupData} isLoggedIn={isLoggedIn}/>} />
          <Route path="/forgot-password" element={<ForgotPasswordPage signupData={signupData} setSignupData={setSignupData} />} />
          <Route path="/reset-password" element={<ResetPasswordPage />} />
          <Route path="/not-found" element={<NotFoundPage />} />
          <Route path="/morphological-classifier" element={<MorphologicalClassifier />} />
          <Route path="/GAN" element={<ImageGenerator />} />
          {/* Define the homepage route as a PrivateRoute */}
          <Route path="/home" element={<PrivateRoute element={<HomePage setIsLoggedIn={setIsLoggedIn} />} />} />

          {/* Define the default route */}
          <Route
            path="/"
            element={
              isLoggedIn ? (
                <Navigate to="/home" />
              ) : (
                <LoginSignupPage setIsLoggedIn={setIsLoggedIn} setSignupData={setSignupData} signupData={signupData} />
              )
            }
          />

          {/* Catch-all route for undefined routes */}
          <Route path="*" element={<Navigate to="/not-found" />} />
          
        </Routes>
      </div>
    </Router>
  );
}

export default App;
