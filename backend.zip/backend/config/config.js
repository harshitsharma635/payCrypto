// config/config.js
module.exports = {
    mongoURI: 'mongodb+srv://sagarikha:sagu123@cluster0.hfvy2fg.mongodb.net/?retryWrites=true&w=majority',
    jwtSecret: 'sagarikha',
  };
