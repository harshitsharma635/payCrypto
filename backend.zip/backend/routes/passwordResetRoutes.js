
const express = require('express');
const router = express.Router();
const passwordResetController = require('../controllers/passwordResetController');

// POST /api/password-reset/forgot
router.post('/forgot', passwordResetController.forgotPassword);

// POST /api/password-reset/reset
router.post('/reset', passwordResetController.resetPassword);

module.exports = router;
