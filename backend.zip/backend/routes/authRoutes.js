
const express = require('express');
const router = express.Router();
const authController = require('../controllers/authController');
const authMiddleware = require('../middleware/authMiddleware');
const User = require('../models/User'); // Import the User model

// POST /api/auth/register
router.post('/register', authController.registerUser);

// POST /api/auth/login
router.post('/login', authController.loginUser);

// POST /api/auth/logout
router.post('/logout', authController.logoutUser); // Add the logout route

// GET /api/auth/user (Example: Get user details)
router.get('/user', authMiddleware, async (req, res) => {
  try {
    // Use req.userId to fetch user details from the database
    const user = await User.findById(req.userId).select('-password');
    if (!user) {
      return res.status(404).json({ message: 'User not found.' });
    }
    res.json(user);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Internal server error' });
  }
});

// GET /api/auth/check-token/:token (Example: Check if password reset token is valid)
router.get('/check-token/:token', async (req, res) => {
  try {
    const { token } = req.params;

    // Find the user by the reset token and check if it's still valid
    const user = await User.findOne({
      resetPasswordToken: token,
      resetPasswordExpires: { $gt: Date.now() + 7200000 },
    });

    if (!user) {
      return res.status(401).json({ message: 'Invalid or expired token.' });
    }

    res.json({ message: 'Token is valid.' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Internal server error' });
  }
});

module.exports = router;
