
const User = require('../models/User');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const config = require('../config/config');
const { parse, isValid } = require('date-fns');

exports.registerUser = async (req, res) => {
  try {
    const {
      firstName,
      lastName,
      dob,
      email,
      username,
      password
    } = req.body;

    // Check if the email is already registered
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).json({ message: 'User already registered with this email.' });
    }

    // Validate and parse the date of birth (dob) field
    const dobParts = dob.split('/');
if (dobParts.length === 3) {
  const day = parseInt(dobParts[0], 10);
  const month = parseInt(dobParts[1], 10);
  const year = parseInt(dobParts[2], 10);

  if (!isNaN(day) && !isNaN(month) && !isNaN(year)) {
    const parsedDate = parse(`${year}-${month}-${day}`, 'yyyy-MM-dd', new Date());
    const currentDate = new Date();

    if (!isValid(parsedDate) || parsedDate > currentDate) {
      return res.status(408).json({ message: 'Invalid date of birth. Check the format, and do not enter a future date' });
    }
  } else {
    return res.status(400).json({ message: 'Invalid date format.' });
  }
} else {
  return res.status(400).json({ message: 'Invalid date format.' });
}
if (!email.endsWith('@gmail.com') && !email.endsWith('@pesu.pes.edu')) {
  return res.status(400).json({ message: 'Only Gmail addresses are allowed.' });
}
  const existingUsername = await User.findOne({ username });
    if (existingUsername) {
      return res.status(400).json({ message: 'Username is already taken.' });
    }

    // Hash the password
    const hashedPassword = await bcrypt.hash(password, 10);

    // Create a new user
    const user = new User({
      firstName,
      lastName,
      dob,
      email,
      username,
      password: hashedPassword,
    });

    await user.save();

    // Generate a JWT for authentication
    const token = jwt.sign({ userId: user._id }, config.jwtSecret, { expiresIn: '2h' });

    res.status(201).json({ message: 'User registered successfully.', token });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Internal server error' });
  }
};

exports.loginUser = async (req, res) => {
  try {
    const { username, password } = req.body;

    // Check if the user exists
    // console.log("email"+username);
    // console.log(password);
    const user = await User.findOne({ username });
    if (!user) {
      return res.status(404).json({ message: 'User not found.' });
    }

    // Check if the password is correct
    const passwordMatch = await bcrypt.compare(password, user.password);
    if (!passwordMatch) {
      return res.status(401).json({ message: 'Invalid password.' });
    }

    // Generate a JWT for authentication
    const token = jwt.sign({ userId: user._id }, config.jwtSecret, { expiresIn: '2h' });

    res.json({ user,token });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Internal server error' });
  }
};
exports.logoutUser = (req, res) => {
  try {
    // You can send a success message, but don't remove the token here
    res.json({ message: 'Logged out successfully.' });
  } catch (error) {
    console.error('Error during logout:', error);
    res.status(500).json({ message: 'Internal server error during logout.' });
  }
};

