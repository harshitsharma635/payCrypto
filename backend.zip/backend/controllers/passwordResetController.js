
// controllers/passwordResetController.js
const bcrypt = require('bcrypt');
const User = require('../models/User');
const crypto = require('crypto');
const nodemailer = require('nodemailer');
const config = require('../config/config');

exports.forgotPassword = async (req, res) => {
  try {
    const { email } = req.body;

    // Check if the user exists
    const user = await User.findOne({ email });
    if (!user) {
      return res.status(404).json({ message: 'User not found.' });
    }

    // Generate a unique password reset token
    const token = crypto.randomBytes(20).toString('hex');

    // Store the token and expiration time in the user document
    user.resetPasswordToken = token;
    user.resetPasswordExpires = Date.now() + 7200000; // Token expires in 2 hours

    await user.save();

    // Send a password reset email with the token
    const transporter = nodemailer.createTransport({
      host: 'smtp.gmail.com',
      port: 465, // Use the correct port for your email service (e.g., 465 for Gmail)
      secure: true, // Use TLS
      auth: {
        user: 'paycryptotemp@gmail.com',
        pass: 'xugqiurgtnubmugp', // Use your Gmail password or an app-specific password
      },
    });
    const resetLink = `http://localhost:3001/reset-password?token=${token}`;
    const mailOptions = {
      from: 'paycryptotemp@gmail.com',
      to: email,
      subject: 'Password Reset',
      text: `To reset your password, click on the following link: ${resetLink}`,
    };

    transporter.sendMail(mailOptions, (error, info) => {
      if (error) {
        console.error(error);
        return res.status(500).json({ message: 'Failed to send password reset email.' });
      } else {
        console.log('Email sent: ' + info.response);
        res.json({ message: 'Password reset email sent.' });
      }
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Internal server error',error: error.message });
  }
};

exports.resetPassword = async (req, res) => {
  try {
    const {newPassword, confirmPassword} = req.body;
    const{token}=req.query;
    console.log("Received token:", token);
    console.log("mmm"+newPassword);
    console.log("tkn"+token)
    // Find the user by the reset token and check if it's still valid
    const user = await User.findOne({
      resetPasswordToken: token,
      resetPasswordExpires: { $gt: Date.now() },
    });
    console.log("user9"+user)
    if (!user) {
     return res.status(401).json({ message: 'Invalid or expired token.' });
    }
   
    // Check if the newPassword and confirmPassword match
    if (newPassword !== confirmPassword) {
      return res.status(400).json({ message: 'Passwords do not match.' });
    }

    // Hash the new password and update the user's password
    const hashedPassword = await bcrypt.hash(newPassword, 10);
    user.password = hashedPassword;
    user.resetPasswordToken = undefined;
    user.resetPasswordExpires = undefined;

    await user.save();

    res.json({ message: 'Password reset successfully.' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Internal server error' });
  }
};
