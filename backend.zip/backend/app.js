
const express = require('express');
const app = express();
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const cors = require('cors');

const noCacheMiddleware = (req, res, next) => {
  res.setHeader('Cache-Control', 'no-store');
  next();
};

app.get('/home', noCacheMiddleware, (req, res) => {
  // Your route handling logic here
  res.send('Welcome to the homepage');
});

// Middleware
app.use(bodyParser.json());
app.use(cors({
    //origin: 'http://localhost:3001', // Replace with the actual URL of your frontend
    methods: ['POST'], // Specify the allowed HTTP methods (POST in this case)
  }));

// Connect to MongoDB
mongoose.connect('mongodb+srv://sagarikha:sagu123@cluster0.hfvy2fg.mongodb.net/?retryWrites=true&w=majority', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});
mongoose.connection.on('connected', () => {
  console.log('Connected to MongoDB');
});

// Routes
const authRoutes = require('./routes/authRoutes');
const passwordResetRoutes = require('./routes/passwordResetRoutes');
app.use('/api/auth', authRoutes);
app.use('/api/password-reset', passwordResetRoutes);
//app.use('/api/logout', )
// Start the server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
