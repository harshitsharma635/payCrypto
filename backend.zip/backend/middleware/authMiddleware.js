
// middleware/authMiddleware.js

const jwt = require('jsonwebtoken');
const config = require('../config/config');
const invalidatedTokens = []; // Array to store invalidated tokens

module.exports = (req, res, next) => {
  // Extract the JWT token from the request headers
  const token = req.header('Authorization');

  // Check if the token is missing
  if (!token) {
    return res.status(401).json({ message: 'Authorization denied. Token missing.' });
  }

  // Check if the token is invalidated (added to the invalidatedTokens array)
  if (invalidatedTokens.includes(token)) {
    return res.status(401).json({ message: 'Authorization denied. Token has been invalidated.' });
  }

  try {
    // Verify the token
    const decodedToken = jwt.verify(token, config.jwtSecret);

    // Attach the user ID to the request for further processing
    req.userId = decodedToken.userId;

    next(); // Continue to the next middleware or route
  } catch (error) {
    console.error(error);
    res.status(401).json({ message: 'Authorization denied. Invalid token.' });
  }
};
