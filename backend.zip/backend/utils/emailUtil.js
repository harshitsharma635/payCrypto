
// utils/emailUtil.js

const nodemailer = require('nodemailer');

// Create a transporter to send emails
const transporter = nodemailer.createTransport({
  host: 'smtp.gmail.com',
  port: 465,
  secure: true, // Use TLS
  auth: {
    user: 'paycryptotemp@gmail.com',
    pass: 'xugqiurgtnubmugp', // Generate this in your Gmail settings
  },
});

// Function to send an email
exports.sendEmail = (to, subject, text) => {
  const mailOptions = {
    from: 'starshipai',
    to,
    subject,
    text,
  };

  transporter.sendMail(mailOptions, (error, info) => {
    if (error) {
      console.error(error);
    } else {
      console.log('Email sent: ' + info.response);
    }
  });
};
