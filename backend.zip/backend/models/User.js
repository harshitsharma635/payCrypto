
const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const userSchema = new Schema({
  firstName: String,
  lastName: String,
  dob: String,
  email: { type: String, unique: true },
  institution: String,
  username: {type:String, unique: true},
  password: String,
  resetPasswordToken: String, // Add this field to store the reset password token
  resetPasswordExpires: Date, // Add this field to store the expiration timestamp
  
});

module.exports = mongoose.model('User', userSchema);
