const { MongoClient } = require('mongodb');

async function checkUserDocument(email) {
  const uri = 'mongodb+srv://sagarikha:sagu123@cluster0.hfvy2fg.mongodb.net/?retryWrites=true&w=majority'; // Your MongoDB connection URI
  const client = new MongoClient(uri);

  try {
    await client.connect();

    const database = client.db('test'); // Replace with your database name
    const collection = database.collection('users'); // Replace with your collection name

    // Find the user by their email
    const user = await collection.findOne({ email });

    if (user) {
      console.log('User found:');
      console.log(user);
    } else {
      console.log('User not found.');
    }
  } catch (error) {
    console.error('Error checking user document:', error);
  } finally {
    client.close();
  }
}

// Usage
checkUserDocument('saagarikha@gmail.com'); // Replace with the email you want to check
